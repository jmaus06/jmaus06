//memo.c

#include "diary.h"
void memo(){
        
        printf("I'm function Memo! \n");
}
