//calendar.c

#include "diary.h"
void calendar(){
        printf("I'm function Calendar() \n");
}
