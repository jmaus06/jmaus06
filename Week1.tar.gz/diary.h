//diary.h

#include <stdio.h>
void memo();
void calendar();
