Joel Maus
Assignment 1
Binary Converter

Makefile commands

binary   -converts int to binary
hex      -converts int to hexadecimal
ones     -calculates number of 1's in binary conversion
